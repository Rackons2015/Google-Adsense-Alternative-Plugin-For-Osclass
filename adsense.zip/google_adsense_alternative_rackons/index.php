<?php
/*
  Plugin Name: Google Adsense Alternative Rackons Plugin
  Plugin URI: http://osclassmarket.rackons.in/
  Description: This is the best alternative of Google Adsense. Instant Approval. Earn upto $20 Per Click.
  Version: 1.0.1
  Author: Rackons
  Author URI: http://server.rackons.co.in
  Short Name: google_adsense_alternative_rackons
 */


function google_adsense_alternative_rackons_admin_menu() {
  
    osc_add_admin_submenu_divider('plugins', 'Google Adsense Alternative Rackons Plugin', 'google_adsense_alternative_rackons', 'administrator');
    osc_add_admin_submenu_page('plugins', __('Settings', 'google_adsense_alternative_rackons'), osc_route_admin_url('google-adsense-alternative-rackons-admin-conf'), 'google_adsense_alternative_rackons_settings', 'administrator');
}

osc_add_route('google-adsense-alternative-rackons-admin-conf', 'google_adsense_alternative_rackons', 'google_adsense_alternative_rackons', osc_plugin_folder(__FILE__).'admin.php'); 

osc_add_hook('admin_menu_init', 'google_adsense_alternative_rackons_admin_menu');
?>