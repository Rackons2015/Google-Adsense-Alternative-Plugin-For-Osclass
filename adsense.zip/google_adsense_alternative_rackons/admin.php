<style type="text/css">
	#content-page { background:#e5e5e5; }
	.col6 { width:47%; float:right; margin:0 10px; }
	.col5 { width:48%; float:left;  margin:0 10px; }
	.form-container { border:2px solid #ddd; background:#fff; }
	.form-container h2 { margin:0; padding:10px 15px; background:#47639e; color:#fff;}
	.form-container fieldset { padding:15px; }
	
	
	.help { color:#999; font-size:12px; }
	.clearfix { clear:both; }
.rac-header{clear: both;padding: 20px;height: 35px; border:1px #0f0f0f;}
.rac_logo {display: block;float:left;opacity:0.7;}
.rac_logo:hover{opacity:1;}
.follow {float:right;color: #333;}
.follow ul li:first-child {font-weight: bold;position: relative;top: 3px;margin: 0 0 0 20px;}
.follow ul li{float: left;margin: -15px 5px 5px 5px;}
.follow li a{opacity: 0.7;text-align: center;line-height: 1px;display: block;border-radius: 100%;font-size: 13px;-webkit-transition: all 0.3s ease-in-out 0s;-moz-transition: all 0.3s ease-in-out 0s;-ms-transition: all 0.3s ease-in-out 0s;-o-transition: all 0.3s ease-in-out 0s;transition: all 0.3s ease-in-out 0s;}
.follow li a:hover {opacity: 1;}
</style>
<div class="rac-header"> <a href="http://rackons.com/" target="_blank" class="rac_logo"> <img src="http://rackons.com/oc-content/uploads/logo.png" alt="Google Adsense Alternative Rackons Plugin" title="Google Adsense Alternative Rackons Plugin" /> </a>
  <div class="follow">
    <ul>
      <li>Follow us <i class="fa fa-hand-o-right"></i></li>
      <li><a href="http://www.facebook.com/rackonscompany" target="_blank" title="facebook"><i class="fa fa-facebook fa-2x"></i> </a></li>
      <li><a href="http://twitter.com/rackonsdotcom" target="_blank" title="twitter"><i class="fa fa-twitter fa-2x"></i> </a></li>
      <li><a href="http://plus.google.com/+RackonsCompany2015" target="_blank" title="google+"><i class="fa fa-google-plus fa-2x"></i> </a></li>

<li><a href="http://osclassmarket.rackons.in" target="_blank" title="Osclass plugins and themes Shop"><i class="fa fa-shopping-bag fa-2x"></i> </a></li>


    </ul>
  </div>
</div>

<div class="clear"></div>	

<div class="plugin-page">
	<div class="col5">
		<?php $pluginInfo = osc_plugin_get_info('google_adsense_alternative_rackons/index.php');  ?>
        <div class="form-container">
        <h2 class="render-title"><?php _e('Google Adsense Alternative Rackons Plugin Settings', 'google_adsense_alternative_rackons'); ?></h2>
       <form name="publisherLogin" id="publisherLogin" method="post" enctype="multipart/form-data" action="http://server.rackons.co.in/ppc-publisher-login-action.php" target="_blank"> 
<table  border="0" cellpadding="0" cellspacing="0" class="loginbox">
<tr><td>&nbsp;</td></tr>
<tr>
<td colspan="2" class="loginbar" style="text-align:center"><h1>Publisher Login</h1></td>
</tr>
<tr>
<td colspan="2" >&nbsp;</td>
</tr>
<tr>
<td> &nbsp; &nbsp; Username</td><td> &nbsp; <input name="username" type="text" id="username" size="25" value="" maxlength="255"></td> 
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td> &nbsp; &nbsp; Password</td><td> &nbsp; <input name="password" type="password" id="password" size="25" value=""></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td >&nbsp;</td>
<td><input type="submit" name="submit" value="Login!" class="submit"></td>
</tr>
<tr>
<td colspan="2" >&nbsp;</td>
</tr>
</table>
</form> 
&nbsp;&nbsp; Start earning from today. <strong>Signing up is FREE </strong> and takes only a minute. <a href="http://server.rackons.co.in/ppc-publisher-registration.php" class="pagetable_activecell" style=" color:#0099CC">Register Now</a><br><br><br><br>
<h1 style="text-align:center; color:red;"><strong>Create Publisher Account <br> and <br> Start Earning upto $20 per click</strong></h1>
     <br><br>   
        </div>
	</div><!-- /Col5 -->
    
    <div class="col6">
    	<div class="form-container">
        <h2 class="render-title"><?php _e('How to Start Earning from Rackons Adserver?', 'google_adsense_alternative_rackons'); ?></h2>
<h3>&nbsp; STEP 1:</h3>
<p style="padding-left:10px;">To start Earning, you need to create Publisher Account. <a href="http://server.rackons.co.in/ppc-publisher-registration.php" target="_blank">Register Here as Publisher</a></p>
<h3>&nbsp; STEP 2:</h3>
<p style="padding-left:10px;">After creating account, you need to submit Publishing URL ( Where you want to show Banner/Text Ads ) </p>
<h3>&nbsp; STEP 3:</h3>
<p style="padding-left:10px;">Create an Ad Units according to your size (Size : 728X90 , 300X250, 160X600 , etc)</p>
<h3>&nbsp; STEP 4:</h3>
<p style="padding-left:10px;">Then Copy the html code and put on your site where you want to display ads ( Which you have created on Rackons Adserver Site ). or you can add that code from your theme settings -> Ads Management</p>
<h3>&nbsp; STEP 4:</h3>
<p style="padding-left:10px;"><strong>DONE!!!</strong> Now Enjoy Rackons Ad Service and Start your Earning from your classified site Today!!! </p>
<p style="padding-left:10px;">If you have any query regarding earning, stats, code then you can ask our expert on Live chat Support. </p>
</div>
    </div><!-- /COL6 -->
    <div class="clearfix"></div>
</div>
<div class="footer">
    <p class="form-row">
    &copy; <?php echo date('Y'); ?> Google Adsense Alternative Rackons Plugin - <a href="http://osclassmarket.rackons.in/osclass-support" target="_blank"><?php _e('Support', 'google_adsense_alternative_rackons'); ?></a> - <a href="http://osclassmarket.rackons.in/">Rackons Market</a>.
    </p>
</div>